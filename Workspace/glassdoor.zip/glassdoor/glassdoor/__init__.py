#!/usr/bin/env python

"""Glassdoor Python API"""

__version__ = "0.0.4"
__author__ = [
    "Mek <michael.karpeles@gmail.com>"
]
__license__ = "public domain"
__contributors__ = "see AUTHORS"

from glassdoor.gd import get, parse
